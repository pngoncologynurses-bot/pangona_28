# PaNGONA 2028 Conference Website

A responsive, single-page conference website starter for the 1st PaNGONA National Oncology Nursing Conference.

## Publish for free with GitHub Pages
1. Create or sign in to a GitHub account.
2. Create a new public repository, for example `pangona-2028`.
3. Upload `index.html` to the repository root.
4. Open **Settings → Pages**.
5. Under **Build and deployment**, choose **Deploy from a branch**, select `main` and `/ (root)`, then Save.
6. GitHub will provide the public website address after deployment.

## Before publishing
- Replace `PASTE-CONFERENCE-EMAIL-HERE` in `index.html` with the official conference email.
- Add PaNGONA's approved logo and official social media links.
- Confirm the programme, abstract deadlines, registration fees, payment instructions, speakers, committee members, sponsorship packages, hotel recommendations and travel information before publishing them.
- Connect registration and abstract forms (e.g. Google Forms) once approved.
- Do not collect payments or patient-identifiable information through this starter website.

The current page intentionally labels unconfirmed information as “coming soon” or “to be announced”.
